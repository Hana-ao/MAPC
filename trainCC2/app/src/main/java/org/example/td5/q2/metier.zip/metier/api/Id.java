package org.example.td5.q2.metier.api;

public interface Id {
    int id(); //renvoie l'id sous forme int (j'avais mis Id de base)
}
